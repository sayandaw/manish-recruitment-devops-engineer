# Kubernetes Assignment

## Environment

Please use either Docker Desktop Kubernetes (Available for [Mac](https://docs.docker.com/docker-for-mac/kubernetes/) and [Windows](https://docs.docker.com/docker-for-windows/kubernetes/)) or [Minikube](https://kubernetes.io/docs/setup/minikube/) for this assignment. You do not need to automate the deployment of the Kubernetes environment.

## Part 1

We would like to deploy our [Java application](https://tomcat.apache.org/tomcat-8.0-doc/appdev/sample/) to K8s, it needs to run in Tomcat 8 and should be available for other pods in the cluster to use (via HTTP) after deployment.

## Part 2

Our application is now ready for production and should be usable by the world. Deploy an ingress into the environment and let people access our service via port 8080. What else would you consider when going to production? Make any appropriate changes and/or comments in README

## Part 3

The world loves our app but its a little unstable and occasionally crashes under heavy load. What can you do to make the system more robust? Include code which implements your solution. In the README describe how you would tell that the app is more stable going forwards. 

## Bonus Task (optional, for senior engineers)

Create a Terraform project that:

- deploys a centos AMI to a new AWS VPC
- I want to be able to curl http://google.com from inside the AMI
- (you choose the rest of the details, if any)
