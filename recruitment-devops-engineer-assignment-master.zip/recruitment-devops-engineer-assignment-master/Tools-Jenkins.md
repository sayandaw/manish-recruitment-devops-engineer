# Pipeline Assignment

## Environment

In this assignment you will be building a Maven project, you can use the following command to create some dummy source code to build in your pipeline:

`mvn archetype:generate -DgroupId=com.mycompany.app -DartifactId=my-app -DarchetypeArtifactId=maven-archetype-quickstart -DarchetypeVersion=1.4 -DinteractiveMode=false`

## Part 1

Write a Jenkins job which would be suitable for building a Maven project in an enterprise banking environment. The job should enforce industry coding style standards, be secure, tested and published to a private maven repository.

You can assume you have an up-to-date instance of Jenkins and are free to use any plugins you want.

In cases where you require any external services, feel free to comment them out explaining what they do. A limited amount of psuedo-code is acceptable.

## Part 2

People love your new Jenkins job and have started copying parts of it to their own projects. You continue to enhance the original job with improvements but after a few months there are dozens of variations of your original job. You need a better way to manage this shared functionality so people are always able to use the latest version of your work. What do you do? Include some code examples.

## Part 3 (for senior engineers and above, optional for others)

Disaster! Our Jenkins server was deleted! Write some code to deploy a new Jenkins pod to our Kubernetes cluster. It should automatically deploy any plugins you use, any jobs from part 1 and and additional configuration done for part 2.

Now that you have a repeatable way to deploy Jenkins, describe in your README how you might productionise and assure operational stability over time.
